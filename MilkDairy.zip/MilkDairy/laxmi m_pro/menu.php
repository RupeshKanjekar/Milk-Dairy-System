<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Producet</title>
    <!-- fontawesome cdn link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- custom css link -->
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- header section starts -->

    <header class="header">

        <a href="#" class="logo"> <i class="fas fa-drumstick-bite"></i> Producet Menu </a>

        <nav class="navbar">
            <a href="menu.php" class="active">menu</a>
            <!--<a href="booking.php">booking</a> -->
            <a href="admin_login.php">+ Add</a>
           
        </nav>

        <div id="menu" class="fas fa-bars"></div>

    </header>

    <!-- header section ends -->

    <div class="heading-title" style="background: url(images/sub-header.jpg) no-repeat;">
        <h1>our menu</h1>
    </div>

    <!-- menu section starts -->
    <h1 class="heading">Product Menu</h1>
    <section class="menu">
    
            <div class="sbox">
                <div class="image">
                    <div class="product-display">
                        <table class="product-display-table">
                            <?php 
                            @include 'config.php';
                            $select = mysqli_query($conn, "SELECT * FROM products");
                            while ($row = mysqli_fetch_assoc($select)) { ?>
                                <tr>
                                    <td><img src="uploaded_img/<?php echo $row['image']; ?>" height="150" width="200" alt=""></td>
                                </tr>
                            <?php } ?>
                        </table>
                    </div>
                </div>
                <div class="content">
                    <?php mysqli_data_seek($select, 0); // Reset the result set pointer ?>
                    <?php while ($row = mysqli_fetch_assoc($select)) { ?>
                        <h3><?php echo $row['name']; ?></h3>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
                        <div class="price">&#8377; <?php echo $row['price']; ?></div>
                        <div class="stars">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star-half-alt"></i>
                        </div>
                        <a href="#" class="btn">______________________________________________________________</a>
                    <?php } ?>
                </div>
            </div>
</section>

    <!-- menu section ends -->

    <!-- footer section starts -->

    <section class="footer">

        <div class="box-container">

            <div class="box">
                <h3>quick links</h3>
                <a href="home.html"> <i class="fas fa-arrow-right"></i> home</a>
                <a href="about.html"> <i class="fas fa-arrow-right"></i> about</a>
                <a href="menu.html"> <i class="fas fa-arrow-right"></i> menu</a>
                <a href="blog.html"> <i class="fas fa-arrow-right"></i> blog</a>
                <a href="booking.html"> <i class="fas fa-arrow-right"></i> booking</a>
            </div>

            <div class="box">
                <h3>extra links</h3>
                <a href="#"> <i class="fas fa-arrow-right"></i> my order</a>
                <a href="#"> <i class="fas fa-arrow-right"></i> my wishlist</a>
                <a href="#"> <i class="fas fa-arrow-right"></i> my favorite</a>
                <a href="#"> <i class="fas fa-arrow-right"></i> my account</a>
                <a href="#"> <i class="fas fa-arrow-right"></i> terms or use</a>
            </div>

            <div class="box">
                <h3>follow us</h3>
                <a href="#"> <i class="fab fa-facebook-f"></i> facebook</a>
                <a href="#"> <i class="fab fa-twitter"></i> twitter</a>
                <a href="#"> <i class="fab fa-instagram"></i> instagram</a>
                <a href="#"> <i class="fab fa-linkedin"></i> linkedin</a>
                <a href="#"> <i class="fab fa-pinterest"></i> pinterest</a>
            </div>

            <div class="box">
                <h3>newsletter</h3>
                <p>subscribe for latest updates</p>
                <form action="">
                    <input type="email" placeholder="enter your email">
                    <input type="submit" value="subscribe" class="btn">
                </form>
            </div>

        </div>

    </section>

    <section class="credit">created by ninjashub | all rights reserved</section>

    <!-- footer section ends -->


    <!-- custom js link -->
    <script src="js/script.js"></script>
    
</body>
</html>
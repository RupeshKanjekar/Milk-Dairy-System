<?php
require('fpdf/fpdf.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Assuming your database credentials
    $servername = "localhost";
    $username = "root";
    $password = "";  // Replace with your actual password
    $dbname = "milcow";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Get form data
    $first_name = $_POST['first_name'];
    $customer_id = $_POST['name'];
    $milk_type = $_POST['job_role'];
    $address = $_POST['address'];
    $total_milk = $_POST['total_milk'];
    $date = $_POST['date'];
    $fat_ret = $_POST['fat_ret'];
    $milk_ret = $_POST['milk_ret'];
    $total_amount = $_POST['total_amount'];


    // Insert data into the database
    $insert_query = "INSERT INTO customer (fname,  cid, mtype, address, tmilk, date, fat_ret, milk_ret, total_amount) 
                     VALUES ('$first_name', '$customer_id', '$milk_type', '$address', '$total_milk', '$date','$fat_ret','$milk_ret','$total_amount')";
    $result = mysqli_query($conn, $insert_query);

    // Check if the query was successful
    if ($result) {
        // PDF creation code
        $pdf = new FPDF();
        $pdf->AddPage();
        $pdf->SetFont('Arial', 'B', 16);
        $pdf->Cell(40, 10, 'Customer Service');
        $pdf->Ln(20);

        $pdf->SetFont('Arial', '', 12);
        $pdf->Cell(40, 10, 'First Name:');
        $pdf->Cell(50, 10, $first_name, 0, 1);

        $pdf->Cell(40, 10, 'Customer ID:');
        $pdf->Cell(50, 10, $customer_id, 0, 1);

        $pdf->Cell(40, 10, 'Milk Types:');
        $pdf->Cell(50, 10, $milk_type, 0, 1);

        $pdf->Cell(40, 10, 'Address:');
        $pdf->Cell(50, 10, $address, 0, 1);

        $pdf->Cell(40, 10, 'Total Milk:');
        $pdf->Cell(50, 10, $total_milk . ' L', 0, 1);

        $pdf->Cell(40, 10, 'Date:');
        $pdf->Cell(50, 10, $date, 0, 1);

        $pdf->Cell(40, 10, 'Fat Ret:');
        $pdf->Cell(50, 10, $fat_ret, 0, 1);

        $pdf->Cell(40, 10, 'Milk Ret :');
        $pdf->Cell(50, 10, $milk_ret, 0, 1);

        $pdf->Cell(40, 10, 'Total Amount:');
        $pdf->Cell(50, 10, $total_amount.' Rs.', 0, 1);

        $pdf->Output();
    } else {
        // Handle the error
        echo "Error: " . $insert_query . "<br>" . $conn->error;
    }

    // Close the database connection
    $conn->close();
} else {
    // Redirect to the form page if accessed directly without submitting the form
    header("Location: your_form_page.php");
    exit();
}
?>
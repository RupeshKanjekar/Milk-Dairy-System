<?php
require('fpdf/fpdf.php'); // Include the FPDF library

if (isset($_POST['generate_pdf'])) {
    // Assuming your database credentials
    $servername = "localhost";
    $username = "root";
    $password = "";  // Replace with your actual password
    $dbname = "milcow";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Fetch data from the database
    $sql = "SELECT * FROM customer";
    $check = mysqli_query($conn, $sql);

    // Initialize FPDF
    $pdf = new FPDF();
    $pdf->AddPage();
    $pdf->SetFont('Arial', 'B', 12);

    // Add table headers
    $pdf->Cell(30, 10, 'First Name', 1);
    $pdf->Cell(30, 10, 'Last Name', 1);
    $pdf->Cell(20, 10, 'CID', 1);
    $pdf->Cell(30, 10, 'Membership Type', 1);
    $pdf->Cell(50, 10, 'Address', 1);
    $pdf->Cell(20, 10, 'Total Milk', 1);
    $pdf->Cell(30, 10, 'Date', 1);
    $pdf->Ln();

    // Add data from the database to the PDF
    while ($data = mysqli_fetch_assoc($check)) {
        $pdf->Cell(30, 10, $data['fname'], 1);
        $pdf->Cell(30, 10, $data['lname'], 1);
        $pdf->Cell(20, 10, $data['cid'], 1);
        $pdf->Cell(30, 10, $data['mtype'], 1);
        $pdf->Cell(50, 10, $data['address'], 1);
        $pdf->Cell(20, 10, $data['tmilk'], 1);
        $pdf->Cell(30, 10, $data['date'], 1);
        $pdf->Ln();
    }

    // Output PDF to the browser
    $pdf->Output();
    
    // Close the database connection
    $conn->close();
} else {
    // Redirect to the page with the table if the button is not clicked
    header("Location: view-data.php");
    exit();
}
?>

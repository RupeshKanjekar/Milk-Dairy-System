<html>
<body>
    <div class="search">
        <form method="GET">
            <input class="srch" type="search" name="search" placeholder="Search here" value="<?php echo isset($_GET['search']) ? $_GET['search'] : '' ?>">
            <button type="submit" class="btn">Search</button>
        </form>

        <?php
        // Assuming your database credentials
        $servername = "localhost";
        $username = "root";
        $password = "";  // Replace with your actual password
        $dbname = "milcow";

        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Filter query based on search input
        $search = isset($_GET['search']) ? $_GET['search'] : '';
        $sql = "SELECT * FROM customer WHERE fname LIKE '%$search%' OR lname LIKE '%$search%' OR cid LIKE '%$search%' OR mtype LIKE '%$search%' OR address LIKE '%$search%' OR tmilk LIKE '%$search%' OR fat_ret LIKE '%$search%' OR milk_ret LIKE '%$search%' OR total_amount LIKE '%$search%' OR date LIKE '%$search%'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // Output data of each row
            echo "<table border='1'>
                    <tr>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>CID</th>
                        <th>Membership Type</th>
                        <th>Address</th>
                        <th>Total Milk</th>
                        <th>Fat_ret</th>
                        <th>Milk_ret</th>
                        <th>Total_amount</th>
                        <th>Date</th>
                    </tr>";

            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>{$row['fname']}</td>
                        <td>{$row['lname']}</td>
                        <td>{$row['cid']}</td>
                        <td>{$row['mtype']}</td>
                        <td>{$row['address']}</td>
                        <td>{$row['tmilk']}</td>
                        <td>{$row['fat_ret']}</td>
                        <td>{$row['milk_ret']}</td>
                        <td>{$row['total_amount']}</td>
                        <td>{$row['date']}</td>
                    </tr>";
            }
            echo "</table>";

            // Add a button to generate PDF
            echo "<form action='gpdf.php' method='post'>
                    <input type='submit' name='generate_pdf' value='Generate PDF'>
                  </form>";
        }
        
        // Close the database connection
        $conn->close();
        ?>
    </div>
</body>

</html>
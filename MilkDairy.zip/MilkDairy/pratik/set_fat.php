<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Set Fat and Enter Rate</title>
<style>
body {
  font-family: Arial, sans-serif;
  background-color: black;
  color: white;
}

.container {
  max-width: 400px;
  margin: 50px auto;
  padding: 20px;
  border: 2px solid #fff; /* White border */
  border-radius: 10px;
  text-align: center;
  background-color: #222;
}

h2 {
  text-align: center;
}

input {
  width: calc(100% - 20px);
  padding: 10px;
  margin: 5px 0;
  background-color: #333;
  color: white;
  border: 2px solid #87CEEB; /* Sky blue glow color */
  border-radius: 5px;
}

#rate {
  text-align: center;
  margin-bottom: 10px;
}

button {
  padding: 10px 20px;
  background-color: #007bff;
  color: #fff;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

button:hover {
  background-color: #0056b3;
}
</style>
</head>
<?php
// Database credentials
$servername = "localhost"; // Replace with your server name
$username = "root";        // Replace with your MySQL username
$password = "";            // Replace with your MySQL password
$dbname = "milcow";        // Replace with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Save rate to the database
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['rate'])) {
    $fatContent = $_POST['fat_content'];
    $rate = $_POST['rate'];

    // Prepare SQL statement
    $stmt = $conn->prepare("INSERT INTO rates (fat_content, rate) VALUES (?, ?)");
    $stmt->bind_param("dd", $fatContent, $rate);

    // Execute the statement
    if ($stmt->execute()) {
        echo "Rate saved successfully!";
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close statement
    $stmt->close();
}

// Close connection
$conn->close();
?>

<body>

<div class="container">
  <h2>Set Fat and Enter Rate</h2>
  <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
    <label for="fatInput">Enter Fat Content:</label>
    <input type="number" id="fatInput" name="fat_content" placeholder="Fat content...">
    <label for="rateInput">Enter Rate (Rs.):</label>
    <input type="number" id="rateInput" name="rate" placeholder="Rate...">
    <div id="rate">Rate will be displayed here</div>
    <button type="submit">Save</button>
  </form>
</div>

<script>
function saveRate() {
  var fatContent = parseFloat(document.getElementById("fatInput").value);
  var rate = parseFloat(document.getElementById("rateInput").value);

  if(isNaN(fatContent) || isNaN(rate)) {
    alert("Please enter valid numbers for fat content and rate.");
    return;
  }

  // Here you can add code to save the rate to the database
  alert("Rate: Rs. " + rate.toFixed(2) + " saved successfully!");
}
</script>
</body>
</html>